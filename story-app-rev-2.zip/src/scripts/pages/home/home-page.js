import AuthHelper from "../../utils/auth-helper";
import HomePresenter from "./home-presenter";
import HomeView from "./home-view";
import StoryModel from "./story-model";
import NotificationHelper from "../../utils/notification-helper";

export default class HomePage {
  constructor() {
    this._view = new HomeView();
    this._model = new StoryModel();
    this._presenter = new HomePresenter({
      view: this._view,
      model: this._model,
    });
  }

  async render() {
    return `
      <section class="container">
        <div id="skip-content" class="skip-content" tabindex="-1"></div>
        <div class="header-container d-flex justify-content-between align-items-center mb-4">
          <h1 class="page-title"><i class="fas fa-book-open icon"></i>Story App</h1>
        </div>
        
        <div class="story-list" id="story-list">
          <div class="loading-indicator">
            <i class="fas fa-spinner fa-spin"></i> Loading stories...
          </div>
        </div>
        
        <div id="map" class="map-container mb-4"></div>
        
        <a href="#/add" class="add-button" aria-label="Add new story">
          <img src="./images/992651.png" width="50px" alt="Story App Logo" class="add-button-logo">
          <i class="fas fa-plus"></i>
        </a>
      </section>
    `;
  }
  
  async afterRender() {
    // Initialize notification system
    await this._initNotifications();
    
    // Check if user is authenticated
    const isAuthenticated = await this._presenter.checkAuthentication();

    if (isAuthenticated) {
      // Load and display stories
      await this._presenter.showStories();
    }
  }
  
  async _initNotifications() {
    try {
      // Register service worker for notifications
      await NotificationHelper.registerServiceWorker();
      
      // Create notification toggle button
      await NotificationHelper.createNotificationToggleButton('notification-container');
      
      // Create toggle for new stories notifications
      NotificationHelper.createNewStoriesNotificationToggle('notification-container');
    } catch (error) {
      console.error('Failed to initialize notifications:', error);
    }
  }

  async cleanup() {
    if (this._presenter) {
      await this._presenter.cleanup();
    }
  }
}
