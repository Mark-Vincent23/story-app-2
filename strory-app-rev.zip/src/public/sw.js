const CACHE_NAME = 'story-app-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/offline.html',
  '/favicon.png',
  '/manifest.json',
  '/images/logo.png',
  '/images/logo-72x72.png',
  '/images/logo-96x96.png',
  '/images/logo-128x128.png',
  '/images/logo-144x144.png',
  '/images/logo-152x152.png',
  '/images/logo-192x192.png',
  '/images/logo-384x384.png',
  '/images/logo-512x512.png',
  '/app.bundle.js',
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching app shell and content');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => {
        console.log('Service Worker: Install completed');
        return self.skipWaiting();
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.filter((cacheName) => {
            return cacheName !== CACHE_NAME;
          }).map((cacheName) => {
            console.log(`Service Worker: Deleting old cache ${cacheName}`);
            return caches.delete(cacheName);
          })
        );
      })
      .then(() => {
        console.log('Service Worker: Activate completed');
        return self.clients.claim();
      })
  );
});

// Fetch event - serve from cache or network
self.addEventListener('fetch', (event) => {
  const requestUrl = new URL(event.request.url);
  
  // Handle navigation requests (HTML pages)
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .catch(() => {
          // If the network is unavailable, serve the offline page
          return caches.match('/offline.html');
        })
    );
    return;
  }
  
  // Skip cross-origin requests
  if (requestUrl.origin !== location.origin) {
    return;
  }
  
  // API requests - network first, then offline handling
  if (requestUrl.pathname.startsWith('/v1')) {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          // Clone the response before consuming it
          const responseToCache = response.clone();
          
          caches.open(CACHE_NAME)
            .then((cache) => {
              // Only cache successful responses
              if (response.status === 200) {
                cache.put(event.request, responseToCache);
              }
            });
          
          return response;
        })
        .catch(() => {
          // If network fails, try to serve from cache
          return caches.match(event.request);
        })
    );
    return;
  }
  
  // Cache first, then network for static assets
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          console.log('Service Worker: Serving from cache', event.request.url);
          return response;
        }
        
        console.log('Service Worker: Fetching from network', event.request.url);
        return fetch(event.request)
          .then((networkResponse) => {
            // Cache the fetched response for future
            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, networkResponse.clone());
              });
            
            return networkResponse;
          })
          .catch((error) => {
            console.error('Service Worker: Fetch failed', error);
            
            // For image requests, return a default offline image
            if (event.request.url.match(/\.(jpg|jpeg|png|gif|svg)$/)) {
              return caches.match('/images/offline-image.png');
            }
            
            // Return a generic response for other resources
            return new Response('Network error occurred', {
              status: 503,
              statusText: 'Service Unavailable',
              headers: new Headers({
                'Content-Type': 'text/plain'
              })
            });
          });
      })
  );
});

// Push notification event
self.addEventListener('push', (event) => {
  console.log('Service Worker: Pushed');

  let notificationData = {};
  
  if (event.data) {
    notificationData = JSON.parse(event.data.text());
  }

  const title = notificationData.title || 'Story App Notification';
  const options = notificationData.options || {
    body: 'New notification from Story App',
    icon: '/images/logo-192x192.png',
    badge: '/images/logo-72x72.png',
    vibrate: [100, 50, 100],
    data: {
      url: '/#/'
    }
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

// Notification click event
self.addEventListener('notificationclick', (event) => {
  console.log('Service Worker: Notification clicked', event.notification);
  
  // Close the notification
  event.notification.close();
  
  // Get the URL to open from the notification data
  const url = event.notification.data && event.notification.data.url 
    ? event.notification.data.url 
    : '/';
  
  // Focus or open window with the URL
  event.waitUntil(
    clients.matchAll({
      type: 'window',
      includeUncontrolled: true
    })
    .then((windowClients) => {
      // Check if there is already a window/tab open with the target URL
      const hadWindowToFocus = windowClients.some((windowClient) => {
        if (windowClient.url === url) {
          // Tab is already open, focus it
          windowClient.focus();
          return true;
        }
        return false;
      });

      // If no existing window, open new one
      if (!hadWindowToFocus) {
        clients.openWindow(url);
      }
    })
  );
});

// Message event - handle messages from the client
self.addEventListener('message', (event) => {
  console.log('Service Worker: Message received', event.data);
  
  if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
    self.registration.showNotification(event.data.title, event.data.options);
  }
});
