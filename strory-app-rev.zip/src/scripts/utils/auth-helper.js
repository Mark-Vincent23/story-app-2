import CONFIG from '../config';

class AuthHelper {
  static TOKEN_KEY = 'auth_token';

  static setAuthToken(token) {
    localStorage.setItem(this.TOKEN_KEY, token);
  }

  static getToken() {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  static removeAuthToken() {
    localStorage.removeItem(this.TOKEN_KEY);
  }

  static isUserLoggedIn() {
    return !!this.getToken();
  }

  static logout() {
    localStorage.removeItem(this.TOKEN_KEY);
    // Redirect to login page after logout
    window.location.hash = '#/login';
  }
}



export default AuthHelper;
