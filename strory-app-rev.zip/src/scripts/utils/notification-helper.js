class NotificationHelper {
    static async registerServiceWorker() {
      if ('serviceWorker' in navigator) {
        try {
          const registration = await navigator.serviceWorker.register('/sw.js');
          console.log('Service Worker registered with scope:', registration.scope);
          return registration;
        } catch (error) {
          console.error('Service Worker registration failed:', error);
          return null;
        }
      }
      return null;
    }
  
    static async requestNotificationPermission() {
      if (!('Notification' in window)) {
        console.log('This browser does not support notifications');
        return false;
      }
  
      try {
        const permission = await Notification.requestPermission();
        return permission === 'granted';
      } catch (error) {
        console.error('Error requesting notification permission:', error);
        return false;
      }
    }
  
    static async subscribeToPushNotification(registration) {
      try {
        const vapidPublicKey = 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk';
        const convertedVapidKey = this._urlBase64ToUint8Array(vapidPublicKey);
  
        const subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: convertedVapidKey,
        });
  
        console.log('Push notification subscription:', subscription);
        
        // Store subscription status in localStorage
        localStorage.setItem('notification_subscribed', 'true');
        
        return subscription;
      } catch (error) {
        console.error('Failed to subscribe to push notifications:', error);
        return null;
      }
    }
    
    static async unsubscribeFromPushNotification() {
      try {
        if (!('serviceWorker' in navigator)) {
          throw new Error('Service Worker not supported');
        }
        
        const registration = await navigator.serviceWorker.ready;
        const subscription = await registration.pushManager.getSubscription();
        
        if (!subscription) {
          console.log('No subscription to unsubscribe from');
          return false;
        }
        
        const result = await subscription.unsubscribe();
        
        if (result) {
          console.log('Successfully unsubscribed from push notifications');
          localStorage.removeItem('notification_subscribed');
        }
        
        return result;
      } catch (error) {
        console.error('Error unsubscribing from push notifications:', error);
        return false;
      }
    }
    
    static async getSubscriptionStatus() {
      try {
        if (!('serviceWorker' in navigator)) {
          return {
            supported: false,
            subscribed: false,
            subscription: null
          };
        }
        
        const registration = await navigator.serviceWorker.ready;
        const subscription = await registration.pushManager.getSubscription();
        
        return {
          supported: true,
          subscribed: !!subscription,
          subscription: subscription
        };
      } catch (error) {
        console.error('Error getting subscription status:', error);
        return {
          supported: true,
          subscribed: false,
          subscription: null,
          error: error.message
        };
      }
    }
    
    static async togglePushNotificationSubscription() {
      const status = await this.getSubscriptionStatus();
      
      if (!status.supported) {
        throw new Error('Push notifications are not supported in this browser');
      }
      
      if (status.subscribed) {
        return await this.unsubscribeFromPushNotification();
      } else {
        // Check permission first
        if (Notification.permission !== 'granted') {
          const permission = await this.requestNotificationPermission();
          if (!permission) {
            throw new Error('Notification permission denied');
          }
        }
        
        const registration = await navigator.serviceWorker.ready;
        return await this.subscribeToPushNotification(registration);
      }
    }
  
    static _urlBase64ToUint8Array(base64String) {
      const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
      const base64 = (base64String + padding)
        .replace(/-/g, '+')
        .replace(/_/g, '/');
  
      const rawData = window.atob(base64);
      const outputArray = new Uint8Array(rawData.length);
  
      for (let i = 0; i < rawData.length; ++i) {
        outputArray[i] = rawData.charCodeAt(i);
      }
      return outputArray;
    }
  
    static async sendStoryCreatedNotification(storyDescription) {
      if (!('Notification' in window)) return;
      
      // If permission is not granted, request it first
      if (Notification.permission !== 'granted') {
        const permission = await this.requestNotificationPermission();
        if (!permission) return;
      }
      
      // Truncate description if it's too long
      const shortDescription = storyDescription.length > 50 
        ? storyDescription.substring(0, 47) + '...' 
        : storyDescription;
      
      const title = 'Story berhasil dibuat';
      const options = {
        body: `Anda telah membuat story baru dengan deskripsi: ${shortDescription}`,
        icon: '/icons/icon-192x192.png',
        badge: '/icons/icon-72x72.png',
        vibrate: [100, 50, 100],
        timestamp: Date.now(),
        data: {
          url: '/#/',
          description: storyDescription
        }
      };
      
      // If service worker is active, use it to show notification
      if (navigator.serviceWorker.controller) {
        const registration = await navigator.serviceWorker.ready;
        await registration.showNotification(title, options);
      } else {
        // Fallback to regular notification
        new Notification(title, options);
      }
      
      return true;
    }
    
    static async sendNewStoryReceivedNotification(story) {
      if (!('Notification' in window)) return;
      
      // Check if notifications are enabled in user preferences
      const notificationsEnabled = localStorage.getItem('notification_new_stories') !== 'false';
      if (!notificationsEnabled) return;
      
      // If permission is not granted, request it first
      if (Notification.permission !== 'granted') {
        const permission = await this.requestNotificationPermission();
        if (!permission) return;
      }
      
      // Extract story details
      const { name, description, photoUrl, id } = story;
      
      // Truncate description if it's too long
      const shortDescription = description.length > 50 
        ? description.substring(0, 47) + '...' 
        : description;
      
      const title = `New Story from ${name}`;
      const options = {
        body: shortDescription,
        icon: photoUrl || '/icons/icon-192x192.png',
        badge: '/icons/icon-72x72.png',
        image: photoUrl,
        vibrate: [100, 50, 100],
        timestamp: Date.now(),
        data: {
          url: `/#/detail/${id}`,
          storyId: id
        }
      };
      
      // If service worker is active, use it to show notification
      if (navigator.serviceWorker.controller) {
        const registration = await navigator.serviceWorker.ready;
        await registration.showNotification(title, options);
      } else {
        // Fallback to regular notification
        new Notification(title, options);
      }
      
      return true;
    }
    
    static async sendNewStoriesReceivedNotification(stories, count) {
      if (!('Notification' in window)) return;
      
      // Check if notifications are enabled in user preferences
      const notificationsEnabled = localStorage.getItem('notification_new_stories') !== 'false';
      if (!notificationsEnabled) return;
      
      // If permission is not granted, request it first
      if (Notification.permission !== 'granted') {
        const permission = await this.requestNotificationPermission();
        if (!permission) return;
      }
      
      // If we have just one story, use the single story notification
      if (count === 1 && stories.length > 0) {
        return this.sendNewStoryReceivedNotification(stories[0]);
      }
      
      const title = 'New Stories Available';
      const options = {
        body: `${count} new stories have been shared. Check them out!`,
        icon: '/icons/icon-192x192.png',
        badge: '/icons/icon-72x72.png',
        vibrate: [100, 50, 100],
        timestamp: Date.now(),
        data: {
          url: '/#/',
          count: count
        }
      };
      
      // If service worker is active, use it to show notification
      if (navigator.serviceWorker.controller) {
        const registration = await navigator.serviceWorker.ready;
        await registration.showNotification(title, options);
      } else {
        // Fallback to regular notification
        new Notification(title, options);
      }
      
      return true;
    }
    
    static setNewStoriesNotificationPreference(enabled) {
      localStorage.setItem('notification_new_stories', enabled ? 'true' : 'false');
    }
    
    static getNewStoriesNotificationPreference() {
      // Default to true if not set
      return localStorage.getItem('notification_new_stories') !== 'false';
    }
    
    static async createNotificationToggleButton(containerId) {
      const container = document.getElementById(containerId);
      if (!container) {
        console.error(`Container with ID ${containerId} not found`);
        return;
      }
      
      // Create the toggle button
      const button = document.createElement('button');
      button.id = 'notification-toggle-btn';
      button.className = 'btn';
      
      // Get current subscription status
      const status = await this.getSubscriptionStatus();
      
      // Set initial button state
      this._updateToggleButtonState(button, status.subscribed);
      
      // Add event listener
      button.addEventListener('click', async () => {
        try {
          button.disabled = true;
          button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
          
          const result = await this.togglePushNotificationSubscription();
          const newStatus = !!result;
          
          this._updateToggleButtonState(button, newStatus);
          
          // Show feedback to user
          const message = newStatus 
            ? 'You have successfully subscribed to notifications!' 
            : 'You have unsubscribed from notifications.';
            
          // You could use a toast notification here or alert
          alert(message);
          
        } catch (error) {
          console.error('Error toggling notification subscription:', error);
          alert(`Error: ${error.message}`);
          
          // Reset button state based on actual status
          const currentStatus = await this.getSubscriptionStatus();
          this._updateToggleButtonState(button, currentStatus.subscribed);
        }
      });
      
      // Add button to container
      container.appendChild(button);
      
      return button;
    }
    
    static _updateToggleButtonState(button, isSubscribed) {
      if (isSubscribed) {
        button.innerHTML = '<i class="fas fa-bell-slash"></i> Unsubscribe from Notifications';
        button.className = 'btn btn-outline-secondary';
      } else {
        button.innerHTML = '<i class="fas fa-bell"></i> Subscribe to Notifications';
        button.className = 'btn btn-primary';
      }
      button.disabled = false;
    }
    
    static createNewStoriesNotificationToggle(containerId) {
      const container = document.getElementById(containerId);
      if (!container) {
        console.error(`Container with ID ${containerId} not found`);
        return;
      }
      
      // Create the toggle switch container
      const toggleContainer = document.createElement('div');
      toggleContainer.className = 'form-check form-switch';
      
      // Create the toggle input
      const toggleInput = document.createElement('input');
      toggleInput.className = 'form-check-input';
      toggleInput.type = 'checkbox';
      toggleInput.id = 'newStoriesNotificationToggle';
      toggleInput.checked = this.getNewStoriesNotificationPreference();
      
      // Create the label
      const label = document.createElement('label');
      label.className = 'form-check-label';
      label.htmlFor = 'newStoriesNotificationToggle';
      label.textContent = 'Notify me when new stories are posted';
      
      // Add event listener
      toggleInput.addEventListener('change', (event) => {
        this.setNewStoriesNotificationPreference(event.target.checked);
      });
      
      // Assemble and append to container
      toggleContainer.appendChild(toggleInput);
      toggleContainer.appendChild(label);
      container.appendChild(toggleContainer);
      
      return toggleInput;
    }
    
    static async showNotification(data) {
      // Check if Notification API is supported
      if (!('Notification' in window)) {
        console.log('This browser does not support notifications');
        return;
      }
      
      // Check permission
      if (Notification.permission !== 'granted') {
        console.log('Notification permission not granted');
        return;
      }
      
      // Check if Service Worker is available and ready
      if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
        // Use Service Worker to show notification
        const title = data.title || 'Story App';
        const options = data.options || {
          body: 'New notification from Story App',
          icon: '/images/logo-192x192.png',
          badge: '/images/logo-72x72.png',
        };
        
        try {
          await navigator.serviceWorker.ready;
          await navigator.serviceWorker.controller.postMessage({
            type: 'SHOW_NOTIFICATION',
            title: title,
            options: options
          });
        } catch (error) {
          console.error('Error showing notification through Service Worker:', error);
          
          // Fallback to regular Notification API
          new Notification(title, options);
        }
      } else {
        // Fallback to regular Notification API
        const title = data.title || 'Story App';
        const options = data.options || {
          body: 'New notification from Story App',
          icon: '/images/logo-192x192.png',
        };
        
        new Notification(title, options);
      }
    }
    
    static isAppInstalled() {
      // Check if app is installed (standalone mode)
      return window.matchMedia('(display-mode: standalone)').matches || 
             window.navigator.standalone === true;
    }
    
    static isPushSupported() {
      return 'PushManager' in window;
    }
    
    static isNotificationSupported() {
      return 'Notification' in window;
    }
    
    static isServiceWorkerSupported() {
      return 'serviceWorker' in navigator;
    }
  }
  
  export default NotificationHelper;
