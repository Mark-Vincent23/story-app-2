self.addEventListener('install', (event) => {
    console.log('Service Worker: Installed');
    self.skipWaiting();
  });
  
  self.addEventListener('activate', (event) => {
    console.log('Service Worker: Activated');
    return self.clients.claim();
  });
  
  self.addEventListener('push', (event) => {
    console.log('Service Worker: Pushed');
  
    let notificationData = {};
    
    if (event.data) {
      notificationData = JSON.parse(event.data.text());
    }
  
    const title = notificationData.title || 'Story App Notification';
    const options = notificationData.options || {
      body: 'New notification from Story App',
      icon: '/icons/icon-192x192.png',
      badge: '/icons/icon-72x72.png',
      vibrate: [100, 50, 100],
      data: {
        url: '/#/'
      }
    };
  
    event.waitUntil(self.registration.showNotification(title, options));
  });
  
  self.addEventListener('notificationclick', (event) => {
    event.notification.close();
  
    // This looks to see if the current is already open and focuses if it is
    event.waitUntil(
      clients.matchAll({ type: 'window' }).then((clientList) => {
        // If a window client is already open, focus it
        for (const client of clientList) {
          if (client.url === '/' && 'focus' in client) {
            return client.focus();
          }
        }
        // Otherwise, open a new window
        if (clients.openWindow) {
          const url = event.notification.data?.url || '/';
          return clients.openWindow(url);
        }
      })
    );
  });
  