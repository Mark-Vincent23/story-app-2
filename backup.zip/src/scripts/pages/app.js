import routes from "../routes/routes";
import { getActiveRoute } from "../routes/url-parser";
import AuthHelper from "../utils/auth-helper";
import NotificationHelper from '../utils/notification-helper';

async function initServiceWorker() {
  const registration = await NotificationHelper.registerServiceWorker();
  if (registration) {
    const permission = await NotificationHelper.requestNotificationPermission();
    if (permission) {
      await NotificationHelper.subscribeToPushNotification(registration);
    }
  }
}


class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;

    this._setupDrawer();
  }

  _setupDrawer() {
    this.#drawerButton.addEventListener("click", () => {
      this.#navigationDrawer.classList.toggle("open");
    });

    // Add logout button event listener
    const logoutButton = this.#navigationDrawer.querySelector("#logout-button");
    if (logoutButton) {
      logoutButton.addEventListener("click", () => {
        AuthHelper.logout();
      });
    }

    document.body.addEventListener("click", (event) => {
      if (
        !this.#navigationDrawer.contains(event.target) &&
        !this.#drawerButton.contains(event.target)
      ) {
        this.#navigationDrawer.classList.remove("open");
      }

      this.#navigationDrawer.querySelectorAll("a").forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove("open");
        }
      });
    });
  }
  

  async renderPage() {
    const url = getActiveRoute();
    const page = routes[url];

    // Call cleanup on the previous page if it exists
    if (this.currentPage && typeof this.currentPage.cleanup === "function") {
      await this.currentPage.cleanup();
    }

    if (!page) {
      this.#content.innerHTML = `
        <div class="container error-page">
          <h2>404 - Page Not Found</h2>
          <p>The page you're looking for doesn't exist.</p>
          <a href="#/" class="back-button">Back to Home</a>
        </div>
      `;
      return;
    }

    try {
      // Clear any previous content
      this.#content.innerHTML = "";

      // Render the new page content
      this.#content.innerHTML = await page.render();

      // Execute any JavaScript after rendering
      await page.afterRender();

      // Store the current page for cleanup later
      this.currentPage = page;
    } catch (error) {
      console.error("Error rendering page:", error);
      this.#content.innerHTML = `
        <div class="container error-page">
          <h2>Error</h2>
          <p>${error.message}</p>
          <a href="#/" class="back-button">Back to Home</a>
        </div>
      `;
    }
  }
  
}
initServiceWorker();
export default App;
