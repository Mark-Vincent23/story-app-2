import AuthHelper from "../../utils/auth-helper";

export default class DetailPresenter {
  #model;
  #view;
  #map = null;
  #marker = null;
  #storyId = null;

  constructor({ model, view }) {
    this.#model = model;
    this.#view = view;
  }

  async showStoryDetail(id) {
    this.#storyId = id;

    try {
      // Check authentication first
      if (!(await this.checkAuthentication())) {
        return;
      }

      // Show loading state
      this.#view.showLoading();

      // Get story details from the model
      const story = await this.#model.getStoryDetail(id);

      // Update the view with story details
      this.#view.showStoryDetail(story);

      // Initialize map if story has location
      if (story.lat && story.lon) {
        this._initMap(story);
      }
    } catch (error) {
      this.#view.showError(error.message);
    }
  }

  _initMap(story) {
    // Wait for the DOM to be fully updated
    setTimeout(() => {
      // Initialize map
      this.#map = this.#view.initMap();

      // Check if map was successfully initialized
      if (!this.#map) {
        console.error("Failed to initialize map");
        return;
      }

      // Add marker for story location
      this.#marker = this.#view.addMarker(this.#map, {
        lat: story.lat,
        lng: story.lon,
        title: story.name,
        id: story.id,
      });

      // Center map on the marker only if both map and marker exist
      if (this.#map && this.#marker) {
        this.#view.centerMapOnMarker(this.#map, this.#marker);
      }
    }, 100);
  }

  async checkAuthentication() {
    if (!AuthHelper.isUserLoggedIn()) {
      this.#view.showAuthRequired();
      return false;
    }
    return true;
  }

  setupEventListeners() {
    // Set up event listeners for the view
    this.#view.setBackButtonHandler(() => {
      window.location.hash = "#/";
    });

    this.#view.setLikeButtonHandler(async () => {
      try {
        await this.#model.likeStory(this.#storyId);
        // Refresh story details to update like count
        this.showStoryDetail(this.#storyId);
      } catch (error) {
        this.#view.showError(error.message);
      }
    });
  }

  cleanup() {
    // Clean up resources when navigating away from the page
    if (this.#marker) {
      this.#view.removeMarker(this.#marker);
      this.#marker = null;
    }
    this.#map = null;
    this.#view.cleanup();
  }
}
