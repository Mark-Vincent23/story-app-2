import routes from "../routes/routes";
import { getActiveRoute } from "../routes/url-parser";
import AuthHelper from "../utils/auth-helper";
import NotificationHelper from '../utils/notification-helper';

async function initServiceWorker() {
  if ('serviceWorker' in navigator) {
    try {
      // Register the service worker
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('Service Worker registered with scope:', registration.scope);
      
      // Request notification permission if needed
      if (registration) {
        const permission = await NotificationHelper.requestNotificationPermission();
        if (permission) {
          await NotificationHelper.subscribeToPushNotification(registration);
        }
      }
      
      // Setup "Add to Home Screen" detection
      setupInstallPrompt();
      
      return registration;
    } catch (error) {
      console.error('Service Worker registration failed:', error);
    }
  }
}

// Handle PWA installation prompt
function setupInstallPrompt() {
  let deferredPrompt;
  
  // Listen for the beforeinstallprompt event
  window.addEventListener('beforeinstallprompt', (event) => {
    // Prevent the default prompt
    event.preventDefault();
    
    // Store the event for later use
    deferredPrompt = event;
    
    // Show a custom install button or notification
    showInstallPrompt(deferredPrompt);
  });
  
  // Handle app installed event
  window.addEventListener('appinstalled', (event) => {
    // Clear the deferredPrompt variable
    deferredPrompt = null;
    
    // Hide the install prompt
    hideInstallPrompt();
    
    // Log the installation
    console.log('PWA was installed');
  });
}

function showInstallPrompt(deferredPrompt) {
  // Create the install notification element if it doesn't exist
  if (!document.getElementById('pwa-install-container')) {
    const installContainer = document.createElement('div');
    installContainer.id = 'pwa-install-container';
    installContainer.className = 'pwa-install-prompt';
    installContainer.innerHTML = `
      <div class="install-content">
        <p>Install Story App for offline use</p>
        <div class="install-actions">
          <button id="pwa-install-button" class="install-button">Install</button>
          <button id="pwa-install-dismiss" class="dismiss-button">Not now</button>
        </div>
      </div>
    `;
    
    // Add to the body
    document.body.appendChild(installContainer);
    
    // Add click event to install button
    document.getElementById('pwa-install-button').addEventListener('click', async () => {
      if (!deferredPrompt) return;
      
      // Show the install prompt
      deferredPrompt.prompt();
      
      // Wait for the user to respond to the prompt
      const { outcome } = await deferredPrompt.userChoice;
      console.log(`User response to the install prompt: ${outcome}`);
      
      // Clear the deferredPrompt variable
      deferredPrompt = null;
      
      // Hide the install prompt
      hideInstallPrompt();
    });
    
    // Add click event to dismiss button
    document.getElementById('pwa-install-dismiss').addEventListener('click', () => {
      hideInstallPrompt();
    });
  }
}

function hideInstallPrompt() {
  const installContainer = document.getElementById('pwa-install-container');
  if (installContainer) {
    installContainer.style.display = 'none';
  }
}


class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;

    this._setupDrawer();
  }

  _setupDrawer() {
    this.#drawerButton.addEventListener("click", () => {
      this.#navigationDrawer.classList.toggle("open");
    });

    // Add logout button event listener
    const logoutButton = this.#navigationDrawer.querySelector("#logout-button");
    if (logoutButton) {
      logoutButton.addEventListener("click", () => {
        AuthHelper.logout();
      });
    }

    document.body.addEventListener("click", (event) => {
      if (
        !this.#navigationDrawer.contains(event.target) &&
        !this.#drawerButton.contains(event.target)
      ) {
        this.#navigationDrawer.classList.remove("open");
      }

      this.#navigationDrawer.querySelectorAll("a").forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove("open");
        }
      });
    });
  }
  

  async renderPage() {
    const url = getActiveRoute();
    const page = routes[url];

    // Call cleanup on the previous page if it exists
    if (this.currentPage && typeof this.currentPage.cleanup === "function") {
      await this.currentPage.cleanup();
    }

    if (!page) {
      this.#content.innerHTML = `
        <div class="container error-page">
          <h2>404 - Page Not Found</h2>
          <p>The page you're looking for doesn't exist.</p>
          <a href="#/" class="back-button">Back to Home</a>
        </div>
      `;
      return;
    }

    try {
      // Clear any previous content
      this.#content.innerHTML = "";

      // Render the new page content
      this.#content.innerHTML = await page.render();

      // Execute any JavaScript after rendering
      await page.afterRender();

      // Store the current page for cleanup later
      this.currentPage = page;
    } catch (error) {
      console.error("Error rendering page:", error);
      this.#content.innerHTML = `
        <div class="container error-page">
          <h2>Error</h2>
          <p>${error.message}</p>
          <a href="#/" class="back-button">Back to Home</a>
        </div>
      `;
    }
  }
  
}
initServiceWorker();
export default App;
